package service;

import model.Customer;
import model.IRoom;
import model.Reservation;

import java.util.*;

public class ReservationService {

    // 1. SINGLETON: Static reference to the single instance
    private static ReservationService reference = null;

    // 2. ENCAPSULATION: Maps are private and non-static (instance-based)
    private final Map<String, IRoom> roomMap = new HashMap<>();
    private final Map<String, Collection<Reservation>> reservationMap = new HashMap<>();

    // 3. SINGLETON: Private constructor prevents outside instantiation
    private ReservationService() {}

    // 4. SINGLETON: Static method to get the single instance
    public static ReservationService getInstance() {
        if (reference == null) {
            reference = new ReservationService();
        }
        return reference;
    }

    // REMOVED 'static' from methods to rely on the Singleton instance
    public void addRoom(IRoom room){
        roomMap.put(room.getRoomNumber(), room);
    }

    public Collection<IRoom> getAllRooms() {
        return roomMap.values();
    }

    public Reservation reserveARoom(Customer customer, IRoom room, Date checkInDate, Date checkOutDate){
        if (isRoomReserved(room, checkInDate, checkOutDate)) {
            // CRITICAL ISSUE FIX: Instead of null, you could throw an exception here
            // depending on how your UI handles it, but usually, UI handles the 'null' check.
            return null;
        }
        Reservation reservation = new Reservation(customer, room, checkInDate, checkOutDate);
        Collection<Reservation> customerReservations = getCustomersReservation(customer);
        if (customerReservations == null) {
            customerReservations = new LinkedList<>();
        }
        customerReservations.add(reservation);
        reservationMap.put(customer.getEmail(), customerReservations);
        return reservation;
    }

    public Collection<IRoom> findRooms(Date checkInDate, Date checkOutDate){
        Collection<IRoom> reservedRooms = getAllReservedRooms(checkInDate, checkOutDate);
        Collection<IRoom> availableRooms = new LinkedList<>();
        for (IRoom room : getAllRooms()) {
            if (!reservedRooms.contains(room)) {
                availableRooms.add(room);
            }
        }
        return availableRooms;
    }

    public Collection<Reservation> getCustomersReservation(Customer customer){
        return reservationMap.get(customer.getEmail());
    }

    public Collection<Reservation> getAllReservations() {
        Collection<Reservation> allReservations = new LinkedList<>();
        for (Collection<Reservation> customerReservations : reservationMap.values()) {
            allReservations.addAll(customerReservations);
        }
        return allReservations;
    }

    private Collection<IRoom> getAllReservedRooms(Date checkInDate, Date checkOutDate) {
        Collection<IRoom> reservedRooms = new LinkedList<>();
        for (Reservation reservation : getAllReservations()) {
            // Logic assumes reservation has a method to check date conflicts
            if (isDateConflict(reservation, checkInDate, checkOutDate)) {
                reservedRooms.add(reservation.getARoom());
            }
        }
        return reservedRooms;
    }

    private boolean isDateConflict(Reservation reservation, Date checkIn, Date checkOut) {
        return checkIn.before(reservation.getCheckOutDate()) && checkOut.after(reservation.getCheckInDate());
    }

    private boolean isRoomReserved(IRoom room, Date checkInDate, Date checkOutDate) {
        Collection<IRoom> reservedRooms = getAllReservedRooms(checkInDate, checkOutDate);
        return reservedRooms.contains(room);
    }

    public IRoom getARoom(String roomNumber) {
        IRoom room = roomMap.get(roomNumber);
        // CRITICAL ISSUE FIX: Throw Exception instead of returning null
        if (room == null) {
            throw new IllegalArgumentException("Error: Room number " + roomNumber + " not found.");
        }
        return room;
    }
}