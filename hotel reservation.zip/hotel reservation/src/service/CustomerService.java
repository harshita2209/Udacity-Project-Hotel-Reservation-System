package service;

import model.Customer;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public class CustomerService {

    // 1. SINGLETON: Static reference to the single instance
    private static CustomerService reference = null;

    // 2. ENCAPSULATION: Map is private and non-static (instance-based)
    private final Map<String, Customer> customerMap = new HashMap<>();

    // 3. SINGLETON: Private constructor prevents outside instantiation
    private CustomerService() {}

    // 4. SINGLETON: Static method to get the single instance
    public static CustomerService getInstance() {
        if (reference == null) {
            reference = new CustomerService();
        }
        return reference;
    }

    // REMOVED 'static' from methods to rely on the Singleton instance
    public void addCustomer(String email, String firstName, String lastName){
        Customer newCustomer = new Customer(firstName, lastName, email);
        customerMap.put(newCustomer.getEmail(), newCustomer);
    }

    public Customer getCustomer(String customerEmail) {
        Customer customer = customerMap.get(customerEmail);

        // CRITICAL ISSUE FIX: Throw Exception instead of returning null
        // This prevents NullPointerExceptions in your Resource/UI layer.
        if (customer == null) {
            throw new IllegalArgumentException("Customer with email " + customerEmail + " not found.");
        }
        return customer;
    }

    public Collection<Customer> getAllCustomers() {
        return customerMap.values();
    }
}