package model;

import java.util.Date;
import java.util.Objects;

public class Reservation {

    private final Customer customer;
    private final IRoom room;
    private final Date checkInDate;
    private final Date checkOutDate;

    public Reservation(Customer customer, IRoom room, Date checkInDate, Date checkOutDate) {
        // VALIDATION: Fixes the "No exception for invalid booking" issue
        if (checkOutDate.before(checkInDate)) {
            throw new IllegalArgumentException("Check-out date cannot be before check-in date.");
        }

        if (customer == null || room == null || checkInDate == null || checkOutDate == null) {
            throw new IllegalArgumentException("Reservation fields cannot be null.");
        }

        this.customer = customer;
        this.room = room;
        this.checkInDate = checkInDate;
        this.checkOutDate = checkOutDate;
    }

    public Date getCheckInDate() {
        return this.checkInDate;
    }

    public Date getCheckOutDate() {
        return this.checkOutDate;
    }

    public Customer getCustomer() {
        return this.customer;
    }

    public IRoom getARoom() {
        return this.room;
    }

    /**
     * Checks if a date range overlaps with this reservation.
     */
    public boolean isRoomReserved(Date checkInDate, Date checkOutDate) {
        // Logic: (StartA < EndB) and (EndA > StartB)
        return checkInDate.before(this.checkOutDate) && checkOutDate.after(this.checkInDate);
    }

    @Override
    public String toString() {
        return "Reservation: " + customer.getFirstName() + " " + customer.getLastName() +
                ", Room: " + room.getRoomNumber() +
                ", Check-in: " + checkInDate +
                ", Check-out: " + checkOutDate;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Reservation that)) return false;
        return Objects.equals(customer, that.customer) &&
                Objects.equals(room, that.room) &&
                Objects.equals(checkInDate, that.checkInDate) &&
                Objects.equals(checkOutDate, that.checkOutDate);
    }

    @Override
    public int hashCode() {
        return Objects.hash(customer, room, checkInDate, checkOutDate);
    }
}