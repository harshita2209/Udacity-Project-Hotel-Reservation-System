package model;

import java.util.Objects;

public class Room implements IRoom {
    // 1. All fields are now PRIVATE and FINAL
    // Also changed variable names to camelCase (standard Java convention)
    private final String roomNumber;
    private final Double price;
    private final RoomType enumeration;

    public Room(String roomNumber, Double price, RoomType enumeration){
        this.roomNumber = roomNumber;
        this.price = price;
        this.enumeration = enumeration;
    }

    @Override
    public String getRoomNumber() {
        return this.roomNumber;
    }

    @Override
    public Double getRoomPrice() {
        return this.price;
    }

    @Override
    public RoomType getRoomType() {
        return this.enumeration;
    }

    @Override
    public boolean isFree() {
        // Safe check for null and zero
        return this.price != null && this.price == 0.0;
    }

    // 2. Added toString() as requested in the "Improvements" section
    @Override
    public String toString() {
        return "Room Number: " + roomNumber +
                " | Price: $" + price +
                " | Type: " + enumeration;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Room room)) return false;
        return Objects.equals(roomNumber, room.roomNumber);
    }

    @Override
    public int hashCode() {
        return Objects.hash(roomNumber);
    }
}