package model;

public class FreeRoom extends Room {

    public FreeRoom(String roomNumber, RoomType enumeration) {
        // Pass 0.0 to the super constructor since it is a FreeRoom
        super(roomNumber, 0.0, enumeration);
    }

    @Override
    public String toString() {
        // Use the getters from the Room class
        return "Free Room - " + super.toString();
    }
}