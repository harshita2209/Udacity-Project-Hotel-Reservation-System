import model.*;
import api.AdminResource;
import api.HotelResource;
import java.util.*; // Consolidated imports for List, Collection, and Collections

public class AdminMenu {
    public static void showOptions(){
        System.out.println("Admin Menu");
        System.out.println("-------------------------------------------------------");
        System.out.println("1. See all Customers");
        System.out.println("2. See all Rooms");
        System.out.println("3. See all Reservations");
        System.out.println("4. Add a Room");
        System.out.println("5. Add Test Data");
        System.out.println("6. Back to Main Menu");
        System.out.println("-------------------------------------------------------");
        System.out.println("Please enter your selection");
    }

    public static boolean executeAdminOptions(Scanner scanner, int adminSelection) {
        boolean keepRunningAdmin = true;
        switch (adminSelection) {
            case 1 -> seeAllCustomers();
            case 2 -> seeAllRooms();
            case 3 -> seeAllReservations();
            case 4 -> addARoom(scanner);
            case 5 -> addTestData();
            case 6 -> keepRunningAdmin = false;
            default -> System.out.println("Please Enter a valid Input between 1 and 6");
        }
        return keepRunningAdmin;
    }

    private static void seeAllCustomers() {
        Collection<Customer> allCustomers = AdminResource.getAllCustomers();
        if (allCustomers.isEmpty()) {
            System.out.println("There are no customers at the moment");
        } else {
            for (Customer customer: allCustomers) {
                System.out.println(customer);
            }
        }
    }

    private static void seeAllRooms() {
        Collection<IRoom> allRooms = AdminResource.getAllRooms();
        if (allRooms.isEmpty()) {
            System.out.println("There are no rooms at the moment");
        } else {
            for (IRoom room: allRooms) {
                System.out.println(room);
            }
        }
    }

    private static void seeAllReservations() {
        Collection<Reservation> allReservations = AdminResource.displayAllReservations();
        if (allReservations == null || allReservations.isEmpty()) {
            System.out.println("There are no reservations at the moment");
        } else {
            for (Reservation reservation: allReservations) {
                System.out.println(reservation);
            }
        }
    }

    private static void addARoom(Scanner scanner) {
        String roomNumber = null;
        boolean validateRoomNumber = false;

        while (!validateRoomNumber) {
            System.out.println("Enter room number: ");
            roomNumber = scanner.nextLine();

            try {
                // Now handled with exceptions
                IRoom roomExist = HotelResource.getRoom(roomNumber);
                System.out.println("That room already exists. Enter y/yes to update room, or any other character to enter another room number: ");
                String userInput = scanner.nextLine();
                if (userInput.equalsIgnoreCase("y") || userInput.equalsIgnoreCase("yes")) {
                    validateRoomNumber = true;
                }
            } catch (IllegalArgumentException ex) {
                // This means the room does NOT exist (which is good for a new room)
                validateRoomNumber = true;
            }
        }

        RoomType roomType = null;
        boolean validateRoomType = false;
        while (!validateRoomType) {
            try {
                System.out.println("Enter a room type (1 for 'SINGLE' bed and 2 for 'DOUBLE' bed): ");
                roomType = RoomType.valueOfNumberOfBeds(Integer.parseInt((scanner.nextLine())));
                validateRoomType = true;
            } catch (Exception ex) {
                System.out.println("Please enter a valid room type (1 or 2)");
            }
        }

        double price = 0.00;
        boolean validateRoomPrice = false;
        while (!validateRoomPrice) {
            try {
                System.out.println("Enter a price per night: ");
                price = Double.parseDouble(scanner.nextLine());
                if (price < 0) {
                    System.out.println("The price must be greater than or equal to 0");
                } else {
                    validateRoomPrice = true;
                }
            } catch (Exception ex) {
                System.out.println("Please enter a valid Price");
            }
        }

        // FIXED: Using Collections.singletonList to convert single Room to List<IRoom>
        Room newRoom = new Room(roomNumber, price, roomType);
        AdminResource.addRoom(Collections.singletonList(newRoom));
        System.out.println("Room added successfully!");
    }

    private static void addTestData() {
        for (int i = 1; i <= 3; i++) {
            String roomNumber = Integer.toString(i);
            RoomType roomType = (i % 2 == 0) ? RoomType.DOUBLE : RoomType.SINGLE;
            double price = (i % 2 == 0) ? 200.00 : 100.00;

            Room newRoom = new Room(roomNumber, price, roomType);
            AdminResource.addRoom(Collections.singletonList(newRoom));
        }

        HotelResource.createACustomer("test1@mail.com", "Williams", "Richard");
        HotelResource.createACustomer("test2@mail.com", "Steve", "Jobs");

        Date today = new Date();
        Calendar c = Calendar.getInstance();

        c.setTime(today);
        c.add(Calendar.DATE, 2);
        Date checkIn = c.getTime();
        c.add(Calendar.DATE, 3);
        Date checkOut = c.getTime();

        try {
            HotelResource.bookARoom("test1@mail.com", HotelResource.getRoom("1"), checkIn, checkOut);
            System.out.println("Test data added!");
        } catch (Exception e) {
            System.out.println("Error adding test data: " + e.getMessage());
        }
    }
}