
import api.HotelResource;
import model.Customer;
import model.IRoom;
import model.Reservation;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.Scanner;

public class MainMenu {

    public static void showOptions() {
        System.out.println("\nWelcome to the Hotel Reservation Application");
        System.out.println("-------------------------------------------------------");
        System.out.println("1. Find and reserve a room");
        System.out.println("2. See my reservation");
        System.out.println("3. Create an account");
        System.out.println("4. Admin");
        System.out.println("5. Exit");
        System.out.println("-------------------------------------------------------");
        System.out.println("Please select a number for the menu option");
    }

    public static boolean executeOption(Scanner scanner, int selection) {
        boolean keepRunning = true;
        switch (selection) {
            case 1 -> findAndReserveARoom(scanner);
            case 2 -> seeMyReservation(scanner);
            case 3 -> createAnAccount(scanner);
            case 4 -> runAdminMenu(scanner);
            case 5 -> {
                System.out.println("Goodbye, hope to see you soon");
                keepRunning = false;
            }
            default -> System.out.println("Please Enter a valid Input between 1 and 5");
        }
        return keepRunning;
    }

    private static void runAdminMenu(Scanner scanner) {
        boolean keepAdminRunning = true;
        while (keepAdminRunning) {
            try {
                AdminMenu.showOptions();
                int adminSelection = Integer.parseInt(scanner.nextLine());
                keepAdminRunning = AdminMenu.executeAdminOptions(scanner, adminSelection);
            } catch (Exception ex) {
                System.out.println("\nPlease enter a number between 1 and 6\n");
            }
        }
    }

    private static String createAnAccount(Scanner scanner) {
        System.out.println("First name: ");
        String firstName = scanner.nextLine();
        System.out.println("Last name: ");
        String lastName = scanner.nextLine();
        String email = null;
        boolean validateEmail = false;

        while (!validateEmail) {
            try {
                System.out.println("Email (format: name@domain.com): ");
                email = scanner.nextLine();
                // FIXED: Removed the syntax error and used the updated method name
                HotelResource.createACustomer(email, firstName, lastName);
                System.out.println("Account created successfully\n");
                validateEmail = true;
            } catch (IllegalArgumentException ex) {
                System.out.println(ex.getLocalizedMessage());
            }
        }
        return email;
    }

    private static void seeMyReservation(Scanner scanner) {
        System.out.println("Please enter your registered Email Address: ");
        String email = scanner.nextLine();

        // Use the plural name we defined in the Singleton Resource
        Collection<Reservation> reservations = HotelResource.getCustomersReservations(email);

        if (reservations == null || reservations.isEmpty()) {
            System.out.println("No reservations found for " + email);
        } else {
            for (Reservation reservation : reservations) {
                System.out.println(reservation);
            }
        }
    }

    private static void findAndReserveARoom(Scanner scanner) {
        Date checkInDate = getValidCheckInDate(scanner);
        Date checkOutDate = getValidCheckOutDate(scanner, checkInDate);

        // Updated method name
        Collection<IRoom> availableRooms = HotelResource.findARoom(checkInDate, checkOutDate);

        if (availableRooms.isEmpty()) {
            Date newCheckIn = getRecommendedDate(checkInDate);
            Date newCheckOut = getRecommendedDate(checkOutDate);
            availableRooms = HotelResource.findARoom(newCheckIn, newCheckOut);

            if (!availableRooms.isEmpty()) {
                System.out.println("No rooms for those dates. Recommendations for " + newCheckIn + " to " + newCheckOut + ":");
                checkInDate = newCheckIn;
                checkOutDate = newCheckOut;
            } else {
                System.out.println("No rooms available.");
                return;
            }
        }

        if (showAvailableRoomsAndAskToBook(scanner, availableRooms)) {
            Customer customer = getCustomerForReservation(scanner);
            if (customer != null) {
                IRoom room = getRoomForReservation(scanner, availableRooms);
                try {
                    // Updated method name and added Exception handling
                    Reservation reservation = HotelResource.bookARoom(customer.getEmail(), room, checkInDate, checkOutDate);
                    System.out.println("Reservation Successful!");
                    System.out.println(reservation);
                } catch (IllegalArgumentException ex) {
                    System.out.println("Error: " + ex.getMessage());
                }
            }
        }
    }

    private static Customer getCustomerForReservation(Scanner scanner) {
        System.out.println("Do you already have an account? (y/n)");
        String choice = scanner.nextLine();
        String email = (choice.equalsIgnoreCase("y")) ? scanner.nextLine() : createAnAccount(scanner);
        return HotelResource.getCustomer(email);
    }

    private static IRoom getRoomForReservation(Scanner scanner, Collection<IRoom> availableRooms) {
        while (true) {
            System.out.println("Enter room number: ");
            String roomNumber = scanner.nextLine();
            try {
                IRoom room = HotelResource.getRoom(roomNumber);
                if (availableRooms.contains(room)) return room;
                System.out.println("That room is not available.");
            } catch (IllegalArgumentException ex) {
                System.out.println("Invalid room number.");
            }
        }
    }

    private static boolean showAvailableRoomsAndAskToBook(Scanner scanner, Collection<IRoom> availableRooms) {
        availableRooms.forEach(System.out::println);
        System.out.println("\nWould you like to book? (y/n)");
        return scanner.nextLine().equalsIgnoreCase("y");
    }

    private static Date getRecommendedDate(Date date) {
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        c.add(Calendar.DATE, 7);
        return c.getTime();
    }

    private static Date getValidCheckInDate(Scanner scanner) {
        SimpleDateFormat df = new SimpleDateFormat("MM/dd/yyyy");
        while (true) {
            System.out.println("Check-in Date (mm/dd/yyyy): ");
            try {
                Date date = df.parse(scanner.nextLine());
                if (date.after(new Date())) return date;
                System.out.println("Date must be in the future.");
            } catch (ParseException e) {
                System.out.println("Format: mm/dd/yyyy");
            }
        }
    }

    private static Date getValidCheckOutDate(Scanner scanner, Date checkIn) {
        SimpleDateFormat df = new SimpleDateFormat("MM/dd/yyyy");
        while (true) {
            System.out.println("Check-out Date (mm/dd/yyyy): ");
            try {
                Date date = df.parse(scanner.nextLine());
                if (date.after(checkIn)) return date;
                System.out.println("Check-out must be after check-in.");
            } catch (ParseException e) {
                System.out.println("Format: mm/dd/yyyy");
            }
        }
    }
}